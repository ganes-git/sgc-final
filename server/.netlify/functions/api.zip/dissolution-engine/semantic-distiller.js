/**
 * Semantic Distiller
 * Responsibilities:
 * - 'Distill' the content based on entropy score.
 * - Remove 'garbage' semantically (filtering noise).
 */

const antigravitySDK = require('../antigravity-sdk');

class SemanticDistiller {
    constructor() { }

    /**
     * Distills the content and vectorizes it.
     * @param {object} dataPacket 
     * @param {number} entropyScore 
     * @returns {object} Distilled result with vector embedding
     */
    async distill(dataPacket, entropyScore) {
        console.log(`[SemanticDistiller] Distilling with entropy factor: ${entropyScore}`);

        const originalText = dataPacket.content;

        // 1. Text Refinement (Simulated)
        const words = originalText.split(/\s+/);
        const threshold = entropyScore > 50 ? 4 : 2;
        const distilledContent = words.filter(w => w.length >= threshold).join(' ');

        // 2. Vector Distillation (Gemini 3 via SDK)
        const vector = await antigravitySDK.vectorizeGemini3(distilledContent);

        return {
            original: originalText,
            distilled: distilledContent,
            reductionRatio: (originalText.length - distilledContent.length) / originalText.length,
            vectorEmbedding: vector
        };
    }
}

module.exports = new SemanticDistiller();
